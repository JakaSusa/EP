package com.example.bodyfatindex_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final EditText masa = findViewById(R.id.masa);
        final EditText telVisina = findViewById(R.id.telesnaVisina);
        final Button btn = findViewById(R.id.button);
        final TextView category = findViewById(R.id.itmCat);
        final TextView itm = findViewById(R.id.itmRez);

        btn.setOnClickListener(v -> {

            try {
                double m = Double.parseDouble(masa.getText().toString());
                double vis = Double.parseDouble(telVisina.getText().toString());
                masa.setText("");
                telVisina.setText("");
                vis = vis/100;
                double rez = m/(vis*vis);
                rez = (double)Math.round(rez * 1000d) / 1000d;
                itm.setText("Vaš indeks telesne mase: "+ String.valueOf(rez));

                if( rez <= 16)
                    category.setText("Huda nedohranjenost");
                else if(rez > 16 && rez <=17)
                    category.setText("Zmerna nedohranjenost");
                else if(rez > 17 && rez <=18.5)
                    category.setText("Blaga nedohranjenost");
                else if(rez > 18.5 && rez <=25)
                    category.setText("Normalna telesna masa");
                else if(rez > 25 && rez <=30)
                    category.setText("Zvečana telesna masa");
                else if(rez > 30 && rez <=35)
                    category.setText("Debelost stopnje 1");
                else if(rez > 35 && rez <=40)
                    category.setText("Debelost stopnje 2");
                else if(rez > 40 )
                    category.setText("Debelost stopnje 3");


            } catch (NumberFormatException e) {
                Log.e("ITM calculator", "Vnesi stevilo", e);
            }


        });
    }
}